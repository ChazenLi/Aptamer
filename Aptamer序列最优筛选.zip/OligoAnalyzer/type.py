from typing import List
from typing import Any
from dataclasses import dataclass


@dataclass
class Structure:
    DetailsURL: str
    ConnectivityURL: str
    Index: int
    ImageThumbLocation: str
    ImageLocation: str
    PrimeBaseIndex: str
    StructureName: str
    SNode: float
    HNode: float
    TMNode: float
    GNode: float
    SessionID: str

    @staticmethod
    def from_dict(obj: Any) -> 'Structure':
        _DetailsURL = str(obj.get("DetailsURL"))
        _ConnectivityURL = str(obj.get("ConnectivityURL"))
        _Index = int(obj.get("Index"))
        _ImageThumbLocation = str(obj.get("ImageThumbLocation"))
        _ImageLocation = str(obj.get("ImageLocation"))
        _PrimeBaseIndex = str(obj.get("PrimeBaseIndex"))
        _StructureName = str(obj.get("StructureName"))
        _SNode = float(obj.get("SNode"))
        _HNode = float(obj.get("HNode"))
        _TMNode = float(obj.get("TMNode"))
        _GNode = float(obj.get("GNode"))
        _SessionID = str(obj.get("SessionID"))
        return Structure(_DetailsURL, _ConnectivityURL, _Index, _ImageThumbLocation, _ImageLocation, _PrimeBaseIndex,
                         _StructureName, _SNode, _HNode, _TMNode, _GNode, _SessionID)


@dataclass
class OutputObj:
    ServiceError: str
    ServiceErrorFlag: bool
    GeneralImageThumbLocation: str
    StructureCount: int
    GeneralImageLocation: str
    Structures: List[Structure]

    @staticmethod
    def from_dict(obj: Any) -> 'OutputObj':
        _ServiceError = str(obj.get("ServiceError"))
        _ServiceErrorFlag = bool(obj.get("ServiceErrorFlag"))
        _GeneralImageThumbLocation = str(obj.get("GeneralImageThumbLocation"))
        _StructureCount = int(obj.get("StructureCount"))
        _GeneralImageLocation = str(obj.get("GeneralImageLocation"))
        _Structures = [Structure.from_dict(y) for y in obj.get("Structures")]
        return OutputObj(_ServiceError, _ServiceErrorFlag, _GeneralImageThumbLocation, _StructureCount,
                         _GeneralImageLocation, _Structures)


@dataclass
class HairpinResult:
    MaxSequenceLength: int
    BatchDate: str
    ActualSequence: str
    ImagesPath: str
    OutputObj: OutputObj
    SequenceName: str
    Sequence: str
    Temperature: str
    PercentSuboptimal: str
    SodiumConc: str
    MagConc: str
    StartPos: str
    StopPos: str
    MaxFoldings: str
    NucleotideType: str
    SequenceType: str
    SessionID: str
    ValidationError: str

    @staticmethod
    def from_dict(obj: Any) -> 'HairpinResult':
        _MaxSequenceLength = int(obj.get("MaxSequenceLength"))
        _BatchDate = str(obj.get("BatchDate"))
        _ActualSequence = str(obj.get("ActualSequence"))
        _ImagesPath = str(obj.get("ImagesPath"))
        _OutputObj = OutputObj.from_dict(obj.get("OutputObj"))
        _SequenceName = str(obj.get("SequenceName"))
        _Sequence = str(obj.get("Sequence"))
        _Temperature = str(obj.get("Temperature"))
        _PercentSuboptimal = str(obj.get("PercentSuboptimal"))
        _SodiumConc = str(obj.get("SodiumConc"))
        _MagConc = str(obj.get("MagConc"))
        _StartPos = str(obj.get("StartPos"))
        _StopPos = str(obj.get("StopPos"))
        _MaxFoldings = str(obj.get("MaxFoldings"))
        _NucleotideType = str(obj.get("NucleotideType"))
        _SequenceType = str(obj.get("SequenceType"))
        _SessionID = str(obj.get("SessionID"))
        _ValidationError = str(obj.get("ValidationError"))
        return HairpinResult(_MaxSequenceLength, _BatchDate, _ActualSequence, _ImagesPath, _OutputObj, _SequenceName,
                             _Sequence, _Temperature, _PercentSuboptimal, _SodiumConc, _MagConc, _StartPos, _StopPos,
                             _MaxFoldings, _NucleotideType, _SequenceType, _SessionID, _ValidationError)

# Example Usage
# jsonstring = json.loads(myjsonstring)
# root = Root.from_dict(jsonstring)
