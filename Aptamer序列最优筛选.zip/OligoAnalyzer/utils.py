import os
from urllib.parse import urlparse, parse_qs

import requests
import xlwings as xw
from PIL import Image

from type import Structure, HairpinResult

BASE_PATH = os.path.abspath('.')


def hairpin(send_data: dict) -> HairpinResult:
    header = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 "
                      "Safari/537.36 ",
    }
    resp = requests.post("https://sg.idtdna.com/calc/analyzer/home/hairpin", json=send_data, headers=header)
    return HairpinResult.from_dict(resp.json())


def generate_sequence(length):
    """
    生成ACGT的全排列数组

    example1:
        length = 1
        output = ["A", "C", "G", "T"]
    example2:
        length = 2
        output = ['AA', 'CA', 'GA', 'TA', 'AC', 'CC', 'GC', 'TC', 'AG', 'CG', 'GG', 'TG', 'AT', 'CT', 'GT', 'TT']

    :param length: 长度
    :return: 全排列
    """
    if length == 1:
        return ["A", "C", "G", "T"]
    tmp = generate_sequence(length - 1)
    res = []
    for i in ["A", "C", "G", "T"]:
        res.extend(j + i for j in tmp)
    return res


def get_image(image_url: str):
    image_name = get_image_name(image_url)
    res = requests.get(image_url)
    image_path = f"{BASE_PATH}/images/{image_name}"
    with open(image_path, 'wb') as f:
        f.write(res.content)
    return image_path


def get_image_name(image_url: str):
    url = urlparse(image_url)
    query = parse_qs(url.query)
    image_name = query.get("img")[0]
    return image_name[image_name.find("/") + 1:]


def get_data(structure: Structure):
    return [structure.Index, "", structure.GNode, structure.TMNode, structure.HNode, structure.SNode]


def add_center(sht: xw.Sheet, target, filepath, match=False, width=None, height=None, column_width=None,
               row_height=None):
    """excel智能居中插入图片

    优先级：match > width & height > column_width & row_height
    建议使用column_width或row_height，定义单元格最大宽或高

    :param sht: 工作表
    :param target: 目标单元格，字符串，如'a1'
    :param filepath: 图片绝对路径
    :param width: 图片宽度
    :param height: 图片高度
    :param column_width: 单元格最大宽度，默认100像素，0 <= column_width <= 1557.285
    :param row_height: 单元格最大高度，默认75像素，0 <= row_height <= 409.5
    :param match: 绝对匹配原图宽高，最大宽度1557.285，最大高度409.5
    """
    unit_width = 6.107  # excel默认列宽与像素的比
    rng = sht.range(target)  # 目标单元格
    name = os.path.basename(filepath)  # 文件名
    _width, _height = Image.open(filepath).size  # 原图片宽高
    not_set = True  # 未设置单元格宽高
    # match
    if match:  # 绝对匹配图像
        width, height = _width, _height
    elif width:
        if not height:  # 指定了宽，等比计算高
            height = width / _width * _height
        if not width:  # 指定了高，等比计算宽
            width = height / _height * _width
    elif height:
        width = height / _height * _width
    elif column_width and row_height:  # 同时指定单元格最大宽高
        width = row_height / _height * _width  # 根据单元格最大高度假设宽
        height = column_width / _width * _height  # 根据单元格最大宽度假设高
        area_width = column_width * height  # 假设宽优先的面积
        area_height = row_height * width  # 假设高优先的面积
        if area_width > area_height:
            width = column_width
        else:
            height = row_height
    elif not column_width and not row_height:  # 均无指定单元格最大宽高
        not_set = False
        column_width = 100
        rng.column_width = column_width / unit_width
        row_height = 75
        rng.row_height = row_height
        width = row_height / _height * _width  # 根据单元格最大高度假设宽
        height = column_width / _width * _height  # 根据单元格最大宽度假设高
        area_width = column_width * height  # 假设宽优先的面积
        area_height = row_height * width  # 假设高优先的面积
        if area_width > area_height:
            height = row_height
        else:
            width = column_width
    else:
        width = row_height / _height * _width if row_height else column_width  # 仅设了单元格最大宽度
        height = column_width / _width * _height if column_width else row_height  # 仅设了单元格最大高度
    assert 0 <= width / unit_width <= 255
    assert 0 <= height <= 409.5
    if not_set:
        rng.column_width = width / unit_width  # 更新当前宽度
        rng.row_height = height  # 更新当前高度
    left = rng.left + (rng.width - width) / 2  # 居中
    top = rng.top + (rng.height - height) / 2
    try:
        sht.pictures.add(filepath, left=left, top=top, width=width, height=height, scale=None, name=name)
    except Exception:  # 已有同名图片，采用默认命名
        pass
