import concurrent.futures
import os
import threading
from concurrent.futures import ThreadPoolExecutor, wait
from copy import deepcopy
from datetime import datetime
from threading import Lock

import xlwings as xw

from type import HairpinResult
from utils import add_center, get_data, get_image, hairpin, generate_sequence

BASE_URL = "https://sg.idtdna.com"
TABLE_HEADER = ["Structure", "Image", "ΔG", "Tm", "ΔH", "ΔS"]
# 结果文件名
RES_FILE_NAME = "result"
# 线程池线程总数
thread_num = 10
# 原始请求数据
raw_data = {
    "settings": {
        "Sequence": "ACATTCTTATTGGGCCTTTTGGCCCAATAAGAATGTAATAAGA",
        "NaConc": 50,
        "MgConc": 0,
        "DNTPsConc": 0,
        "OligoConc": 0.25,
        "NucleotideType": "DNA"
    },
    "hairpinSettings": {
        "SequenceType": "Linear",
        "MaxFoldings": 20,
        "StartPos": 0,
        "StopPos": 0,
        "Temp": 25,
        "Suboptimality": 50
    }
}

sequence = generate_sequence(3)
# 请求数据
datas = []

# 生成请求数据数组
for s in sequence:
    # 深拷贝原始数据，一定要深拷贝！！！
    tmp = deepcopy(raw_data)
    # 设置你想要的数据
    tmp["settings"]["Sequence"] = f"ACATTCTTATTGGGCCT{s}GGCCCAATAAGAATGTAATAAGA"
    # 加入请求数据数组
    datas.append(tmp)

task_num = len(datas)
res_data: HairpinResult | None = None
res_lock = Lock()

def worker(send_data):
    global res_data, res_lock, task_num
    try:
        res = hairpin(send_data)

        res_lock.acquire()
        task_num -= 1
        print(
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [{format((1 - task_num / len(datas)) * 100, '.2f')}%] "
            f"{threading.current_thread().name} with sequence: {send_data['settings']['Sequence']}")
        if res_data is None or res_data.OutputObj.Structures[0].GNode > res.OutputObj.Structures[0].GNode:
            res_data = res
        res_lock.release()
    except Exception as e:
        print(e)


pool = ThreadPoolExecutor(max_workers=thread_num, thread_name_prefix="worker")
futures = [pool.submit(worker, send_data) for send_data in datas]
print("等待请求结束...")
start_time = datetime.now()
wait(futures)
end_time = datetime.now()
print(f"所有任务完成！总共花费时间 {end_time-start_time}")

if not os.path.exists("./images"):
    os.mkdir("./images")

if res_data is not None:
    print(f"正在写入{RES_FILE_NAME}.xlsx ...")
    with xw.App(visible=False, add_book=False) as app:
        book = app.books.add()
        sheet = book.sheets.add()

        sheet.range((1, 1)).value = TABLE_HEADER

        for idx, val in enumerate(res_data.OutputObj.Structures):
            data = get_data(val)
            sheet.range((2 + idx, 1)).value = data
            image_path = get_image(BASE_URL + val.ImageLocation)
            add_center(sheet, (2 + idx, 2), image_path)

        book.save(f"{RES_FILE_NAME}.xlsx")
        print("成功！")
else:
    print("未得到数据，请求错误！")
